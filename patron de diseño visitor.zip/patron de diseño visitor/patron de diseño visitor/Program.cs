﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace patron_de_diseño_visitor
{
    public class Program
    {
        static void Main(string[] args)
        { 
            interface IVisitor
        {
            void Visitar(Ropa ropa);
            void Visitar(Electronico electronico);
            void Visitar(Alimento alimento);
        }

        
        interface IProducto
        {
            void Aceptar(IVisitor visitor);
        }

        class Ropa : IProducto
        {
            public double Precio { get; set; }

            public Ropa(double precio)
            {
                Precio = precio;
            }

            public void Aceptar(IVisitor visitor)
            {
                visitor.Visitar(this);
            }
        }
        class Electronico : IProducto
        {
            public double Precio { get; set; }

            public Electronico(double precio)
            {
                Precio = precio;
            }

            public void Aceptar(IVisitor visitor)
            {
                visitor.Visitar(this);
            }
        }
        class Alimento : IProducto
        {
            public double Precio { get; set; }

            public Alimento(double precio)
            {
                Precio = precio;
            }

            public void Aceptar(IVisitor visitor)
            {
                visitor.Visitar(this);
            }
        }

        class CalculadorImpuesto : IVisitor
        {
            public void Visitar(Ropa ropa)
            {
                Console.WriteLine("Impuesto de ropa: " + ropa.Precio * 0.19);
            }

            public void Visitar(Electronico electronico)
            {
                Console.WriteLine("Impuesto de electrónico: " + electronico.Precio * 0.19);
            }

            public void Visitar(Alimento alimento)
            {
                Console.WriteLine("Impuesto de alimento: " + alimento.Precio * 0.05);
            }
        }

        class Program
        {
            static void Main()
            {
                Ropa camisa = new Ropa(50000);
                Electronico celular = new Electronico(1000000);
                Alimento comida = new Alimento(20000);

                CalculadorImpuesto impuesto = new CalculadorImpuesto();

                camisa.Aceptar(impuesto);
                celular.Aceptar(impuesto);
                comida.Aceptar(impuesto);
            }
        }
    }
    }
}
