﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace patron_de_diseño_visitor
{
    interface Iproducto
    {
        void Aceptar(IVisitor visitor);
    }
}
